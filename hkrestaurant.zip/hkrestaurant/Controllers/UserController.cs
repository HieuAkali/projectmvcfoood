﻿using hkrestaurant.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace hkrestaurant.Controllers
{
    public class UserController : Controller
    {
        DataClasses1DataContext data = new DataClasses1DataContext();
        // GET: User
        public ActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public ActionResult Dangky()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Dangky(FormCollection collection, acckh acckh)
        {
            var taikhoan = collection["kh_taikhoan"];
            var matkhau = collection["kh_matkhau"];
            var hoten = collection["kh_tendaydu"];
            var sdt = collection["kh_sdt"];
            var email = collection["kh_email"];
            if (string.IsNullOrEmpty(taikhoan))
            {
                ViewData["Loi1"] = "khong dc de trong";
            }
            else if (string.IsNullOrEmpty(matkhau))
            {
                ViewData["Loi2"] = "khong dc de trong";
            }
            else if (string.IsNullOrEmpty(hoten))
            {
                ViewData["Loi3"] = "khong dc de trong";
            }
            else if (string.IsNullOrEmpty(sdt))
            {
                ViewData["Loi4"] = "khong dc de trong";
            }
            else if (string.IsNullOrEmpty(email))
            {
                ViewData["Loi5"] = "khong dc de trong";
            }
            else
            {
                acckh.kh_taikhoan = taikhoan;
                acckh.kh_matkhau = matkhau;
                acckh.kh_tendaydu = hoten;
                acckh.kh_sdt = sdt;
                acckh.kh_email = email;
                data.acckhs.InsertOnSubmit(acckh);
                data.SubmitChanges();
                return RedirectToAction("Dangnhap");
            }
            return this.Dangky();

        }
        [HttpGet]
        public ActionResult Dangnhap()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Dangnhap(FormCollection collection)
        {
            var taikhoan = collection["kh_taikhoan"];
            var matkhau = collection["kh_matkhau"];
            if (string.IsNullOrEmpty(taikhoan))
            {
                ViewData["Loi1"] = "khong dc de trong";
            }
            else if (string.IsNullOrEmpty(matkhau))
            {
                ViewData["Loi2"] = "khong dc de trong";
            }
            else
            {
                acckh kh = data.acckhs.SingleOrDefault(n => n.kh_taikhoan == taikhoan && n.kh_matkhau == matkhau);
                if (kh != null)
                {
                    Session["Taikhoan"] = kh.kh_ma;
                    return RedirectToAction("Index", "Home");
                }
                else
                    ViewBag.Thongbao = "sai thong tin dang nhap ";
            }
            return View();

        }
    }
}